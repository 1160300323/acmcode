##### marthe

##### Version 1. 0. 1
1. 拉取bugly原始数据以自定义的格式落库